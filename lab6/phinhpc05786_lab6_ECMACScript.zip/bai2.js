import {uppercaseString, lowercaseString} from "./bai1.js";

console.log(uppercaseString('nguyễn Hoàng Phi')); 
console.log(lowercaseString('Phi Nguyễn Hoàng'));