export default function subtract(x,y){
    return x - y;
}