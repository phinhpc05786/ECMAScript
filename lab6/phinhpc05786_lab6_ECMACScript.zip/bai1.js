export const uppercaseString = (string) => {
    return string.toUpperCase();
}

export const lowercaseString = (string) => {
    return string.toLowerCase();
}