import subtract from "./bai3.js";



console.log(subtract(7,4));