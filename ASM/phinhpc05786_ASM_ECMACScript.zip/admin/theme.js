// sidenav toggle
$(document).ready(function () {
    $("#menu").click(function () {
        $("#sidenav").toggle();
    });
    $("#menu2").click(function () {
        $("#sidenav").toggle();
    });
});

