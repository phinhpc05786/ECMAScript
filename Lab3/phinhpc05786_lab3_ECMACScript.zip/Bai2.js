console.log("--------Bài 2-----------");

const sum = () => {
    let arr = [1,2,3,4,5,6,7];
    let tinhTong = 0;
    arr.forEach ((e) =>{
        tinhTong += e;
    })
    console.log(tinhTong);
}

sum();

