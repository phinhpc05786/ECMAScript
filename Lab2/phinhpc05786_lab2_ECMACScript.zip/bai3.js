console.log("-------------Bài 3---------");

function spreadOut() {
    let fragment = ['to', 'code'];
    let sentence = [...fragment];
    return sentence;
}

console.log(spreadOut());